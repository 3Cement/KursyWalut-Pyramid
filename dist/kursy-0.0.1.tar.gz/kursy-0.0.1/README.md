# Kursy Walut - Pyramid

Jest to program synchronizujący aktualne kursy walut ze strony NBP.